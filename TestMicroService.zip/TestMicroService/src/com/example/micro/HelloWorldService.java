package com.example.micro;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldService {
	
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public String testGet() {
		
		return "Welcome To First Microservice...GET!";
	}
	@RequestMapping(value="/test1", method=RequestMethod.POST)
	public String testPost() {
		
		return "Welcome To First Microservice..POST!";
	}

}
